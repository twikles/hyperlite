import { useEffect } from "react";
import Header from "./Header";
import Sidebar from "./Sidebar";
import CentralPanel from "./CentralPanel";
import TaskLogPanel from "./TaskLogPanel";
import ToastContainer from "../components/ToastContainer";
import { useInfraStore } from "../store/useInfraStore";
import { useUrlParamsToSelection, useSelectionToUrl } from "../hooks/useUrlSync";

const REFRESH_MS = 6000;

export default function AppShell() {
  const loadAll = useInfraStore((s) => s.loadAll);
  const refreshAll = useInfraStore((s) => s.refreshAll);
  const loading = useInfraStore((s) => s.loading);
  const error = useInfraStore((s) => s.error);

  useUrlParamsToSelection();
  useSelectionToUrl();

  useEffect(() => { loadAll(); }, [loadAll]);

  // Rafraichit en arriere-plan (voir refreshAll dans le store) pour que les
  // changements faits par un autre utilisateur/onglet apparaissent sans
  // recharger la page a la main. Sans effet visible pendant le chargement
  // initial (loadAll s'en charge deja) ni sur un echec transitoire.
  useEffect(() => {
    const id = setInterval(refreshAll, REFRESH_MS);
    return () => clearInterval(id);
  }, [refreshAll]);

  return (
    <div className="flex h-screen overflow-hidden bg-anthracite-900">
      <Sidebar />
      <div className="flex flex-1 flex-col overflow-hidden">
        <Header />
        <div className="flex-1 overflow-hidden">
          {loading ? (
            <div className="flex h-full items-center justify-center text-sm text-anthracite-400">Chargement de l'infrastructure...</div>
          ) : error ? (
            <div className="flex h-full items-center justify-center text-sm text-status-error">Erreur : {error}</div>
          ) : (
            <CentralPanel />
          )}
        </div>
        {/* BUG REEL trouve en testant a l'oeil (Playwright) : place comme
            frere direct de la colonne Sidebar+contenu (conteneur racine en
            flex-row depuis la refonte 2026-09-17), TaskLogPanel se rendait
            comme une colonne etroite a droite de tout l'ecran au lieu d'une
            barre en bas -- avant la refonte, le conteneur racine etait en
            flex-col, donc le meme JSX se comportait correctement. Remis a
            l'interieur de la colonne contenu (sous Header+CentralPanel). */}
        <TaskLogPanel />
      </div>
      <ToastContainer />
    </div>
  );
}
